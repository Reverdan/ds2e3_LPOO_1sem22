using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TesteSoma
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Soma.
        }
    }
}