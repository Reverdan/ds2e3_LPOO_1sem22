﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soma.modelo
{

    internal class Calculos
    {
        public Double Calcular(Double num1, Double num2)
        {
            return num1 + num2;
        }
    }
}
